Django Debug Toolbar
====================

.. toctree::
   :maxdepth: 2

   installation
   configuration
   tips
   panels
   commands
   changes
   contributing
