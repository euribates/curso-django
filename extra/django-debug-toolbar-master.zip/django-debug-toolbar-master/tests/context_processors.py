def broken(request):
    request.non_existing_attribute
