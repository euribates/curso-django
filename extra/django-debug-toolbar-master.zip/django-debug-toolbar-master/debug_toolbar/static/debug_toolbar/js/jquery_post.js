var djdt = {jQuery: jQuery.noConflict(true)}; window.define = _djdt_define_backup;
