# SQLFormat configuration

# Debug flag
DEBUG = True

# Secret key, please change this
SECRET_KEY = 'notsosecret'
